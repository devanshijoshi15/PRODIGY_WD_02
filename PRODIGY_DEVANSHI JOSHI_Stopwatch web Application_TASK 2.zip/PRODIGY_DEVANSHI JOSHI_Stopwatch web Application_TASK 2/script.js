let startTime = null;
let intervalId = null;
let running = false;

const timeDisplay = document.querySelector(".time-display");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("pause");
const resetButton = document.getElementById("reset");
const lapButton = document.getElementById("lap");
const lapList = document.getElementById("lap-list");

function formatTime(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(2);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

function updateDisplay() {
    const currentTime = Date.now() - startTime;
    timeDisplay.textContent = formatTime(currentTime);
}

function start() {
    if (!running) {
        startTime = Date.now();
        intervalId = setInterval(updateDisplay, 10);
        running = true;
    }
}

function pause() {
    clearInterval(intervalId);
    running = false;
}

function reset() {
    clearInterval(intervalId);
    running = false;
    startTime = null;
    timeDisplay.textContent = "00:00.00";
    lapList.innerHTML = "";
}

function lap() {
    if (running) {
        const currentTime = Date.now() - startTime;
        const lapTime = formatTime(currentTime);
        const lapItem = document.createElement("li");
        lapItem.textContent = lapTime;
        lapList.appendChild(lapItem);
    }
}

startButton.addEventListener("click", start);
pauseButton.addEventListener("click", pause);
resetButton.addEventListener("click", reset);
lapButton.addEventListener("click", lap);

// Automatically start the stopwatch when the page loads
start();
